<footer class="ng-scope">
    <div class="jumbotron" style="margin-bottom: 0%">
        <!-- Example row of columns -->
        <center><div class="row" center >
          
          <div class="col-md-12" >
            <h2>CONTACTO</h2>
            <p align="justify"><center> Estamos a su servicio habla con nostros!</center></p>
            <ul>
                    <center><p class="email"><center>hevapasteleria@gmail.com</center>  </p>
                    <p class="phone">6623608926</p>
                    <p class="chat"><a href="https://www.facebook.com/HEVAPasteleria/"><img src="http://localhost:8080/PROYECTO/img/FB.png" width="30" height="30"  alt="fb"></a></p></center>
                </ul>
            
          </div>
          
        </div></center>
        
        <a class="btn btn-secondary" href="<?=base_url()?>index.php/login/index" role="button">Panel</a>
      
    </div> <!-- /container -->
</footer>