  <head>
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
      <meta name="description" content="">
      <meta name="author" content="">
      <link rel="icon" class=href="http://localhost:8080/PROYECTO_HEVA/img/logoheva.png">
      <img class="d-block w-100" src="http://localhost:8080/PROYECTO_HEVA/img/Col.jpg" alt="pastel">

      <title>HEVA</title>
  </head>

      <nav class="navbar navbar-expand-lg navbar-dark  justify-content-between" style="background-color: rgb(175, 28, 128);">
    
       <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navarSupportedContent" aria-controls="navarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
 
    <div class="navbar-nav-scroll collapse navbar-collapse" id="navarSupportedContent">
          <ul class="navbar-nav flex-row">
            <li>
              <a class="navbar-brand" href="<?=base_url()?>index.php/"><img src="http://localhost:8080/PROYECTO_HEVA/img/logoheva.png" width="30" height="30"  alt="pastel">INICIO</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="<?=base_url()?>index.php/sucursales/psucursal/">Sucursales</a>
            </li>
            <!-- <li class="nav-item">
                <a class="nav-link" href="<?=base_url()?>index.php/productos/pproducto/">Productos</a>
            </li>-->
          </ul>
      </div>
   <!--   <form class="form-inline">

         <a href="<?=base_url()?>index.php/usuarios/cerrar_sesion" class="btn btn-outline-primary my-2 my-sm-0" role="button" aria-pressed="true">Cerrar Sesion</a>
      </form>-->
   </nav>   